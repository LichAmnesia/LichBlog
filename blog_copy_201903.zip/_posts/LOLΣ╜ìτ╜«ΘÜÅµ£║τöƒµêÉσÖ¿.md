---
title: LOL位置随机生成器
tags:
  - game
date: 2014-02-02 15:31:46
---

链接地址:[http://alwa.name/lol.html](http://alwa.name/lol.html)

	舍友说什么以后宿舍开黑LOL来一个随机生成的位置,一时兴起花了两个小时用js写了一下这个生成器.功能简单,界面丑陋.

	 

	暂时先这样,等开学再加新功能和美化