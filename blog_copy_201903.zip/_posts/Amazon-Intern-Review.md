---
title: Amazon Intern Review
date: 2017-08-17 10:43:36
tags:
    - 总结
---

# 1. Life
### Hiking
Go hiking three times. Seattle is very beautiful place when you like. 2 weeks hiking one time. 

<!-- more -->

- Twin springs falls
- lake 22
- Mt. Rainier, summerland trail.

The first time, we just go with the people that I don't know until the day we go out. The trail is not very far away to the Seattle. We Uber and then split it. Takes about one hour to go there. The view is not so wonderful that I thought. Because we don't know each other. Not very fun.

The second time, we go to Lake 22 Trail. It's a 6 miles trail. This is a very beautiful place. Amazing! That's I want to say about the lake. One side with full of snow, another side is full of green. 

The third time, we go to Mt. Rainier. I want to go the Mountain for a long time. Because you can see the mountain from everywhere in Seattle, the idea will come to you that I need to see it closer. This is the best hiking experience that I have in Seattle. Maybe because the friends come with me make me happy with that.


### Board Games
Another great thing in Seattle is that I organize board games in maple hall. I know a lot of friends when I play werewolf. I take one werewolf from China, it's cute.


### Places 
Smith Tower is place that good to remember. Columnbia Center is the highest place in Seattle. There are not a lot places that need to visit in downtown Seattle. Also no matter where you go, what matters is who you go with.

### Restraunts
**Seafood:** RockCreek, Elliott's Oyster 
**Chinese:** Boiling Point, Ming China Bistro, Peony
**Drink:** ShareTea, Kung Fu Tea, Starbucks Reserve
**Sushi & Japanese:** Japonessa, Sushi Kashiba, Kizuki Ramen, SUIKA Seattle

# 2. Work
The intern is not so challenging compared to what I thought. Maybe because I am in the Advertising team, which is a bussiness leadered team not a technical leadered team. 

But my work is about launch a new feature in Amazon. And the customers are real advertisers in the world, which makes me feel better. It has the design docs and technical spec. I just need to follow the roadmap. Even though I haven't touch the design part. It also helps me have a view of what they do.

In the work, it's like you create a story about what you want to do next two weeks. In the demo part, better to demo than not. Better do tell others your questions, your thoughts. Don't be quite!

If you have questions just ask, people are friendly to help you. But if you don't ask. Others will not know what you do. Maybe you are talented, but who knows.


