---
title: The end of NJUST ACM Group
date: 2015-06-18 23:24:38
tags:
---

终于还是做出了这样的决定，在此立证，务必做到以下：

I do not forgive
I do not forget