---
title: Note for Computer Analysis of Human Behaviors
date: 2017-08-17 20:56:59
tags:
    - Note
    - mathematic
---

Note for the book `Computer Analysis of Human Behaviors`

{% pdf http://7xrh75.com1.z0.glb.clouddn.com/Note%20for%20Computer%20Analysis%20of%20Human%20Behaviors.pdf %}

<!-- 文件在七牛上，Note for Computer Analysis of Human Behaviors.pdf-->

