---
title: CodeForces 205C Little Elephant and Interval
tags:
  - ACM
date: 2013-11-21 10:02:20
---

找出规律，最后一位对数据的影响只在和最前一位的大小关系上，然后去掉最后一位其他的都是可行的，最后加上1-9。